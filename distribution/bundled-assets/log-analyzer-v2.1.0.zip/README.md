# 系统诊断插件

这是 Hephaestus Workbench v2 的系统诊断进程扩展。扩展复用现有 Go 分析引擎，通过 `analysis-process-v1` 与宿主交换单个 JSON 请求和响应。

## 工作台协议

宿主在 stdin 写入一次请求并关闭输入：

```json
{
  "protocol": "analysis-process-v1",
  "requestId": "request-1",
  "caseId": "case-1",
  "sourcePath": "C:/Logs/device.tgz",
  "outputDirectory": "C:/Workbench/Cases/case-1/Extract/Report",
  "extractDirectory": "C:/Workbench/Cases/case-1/Extract",
  "scope": "comprehensive"
}
```

扩展在 stdout 只写入一次响应。成功响应不包含报告路径：

```json
{
  "protocol": "analysis-process-v1",
  "requestId": "request-1",
  "succeeded": true
}
```

报告入口固定为：

```text
<extractDirectory>/Report/index.html
```

插件支持 `comprehensive`（综合日志分析）与 `storage`（存储健康分析）。两种范围均只生成 `<extractDirectory>/Report/index.html`；存储范围默认展示故障结论优先的存储健康诊断报告。

## 本地开发

需要 Go 1.24 或更高版本：

```powershell
go test ./...
go vet ./...
go build -buildvcs=false -trimpath -o log_analyzer.exe .
```

发布 ZIP 应直接包含 `log_analyzer.exe`、`manifest.json` 和 `README.md`。正式发布包还必须由发布流水线计算 SHA-256，并使用受信任发布者的 Ed25519 私钥签名原始 ZIP 字节。
